const {
    PersonalTable,
    GrowTable,
    EvolveTable,
    EggMovesTable,
    LearnsetTable,
    MovesTable,
    basePokemonNames,
    formPokemonNames,
    pokemonHeight,
    pokemonWeight,
    pokemonDexType,
    pokemonPokedexInfo,
    natureNames,
    abilityNames,
    abilityInfo,
    typeName,
    moveNames,
    moveInfo,
    ItemTable,
    itemNames
} = require('./__gamedata');


const POKEMON_MAP = basePokemonNames.labelDataArray.reduce((acc, curr, i) => {
    const name = curr.wordDataArray[0].str;
    acc[name] = i;
    return acc;
}, {});

const MsgEventIDEnum = {
    0: '',
    1: '\n',
    3: '\f',
    7: ''
}

const EVOLUTION_METHODS = [
    "", "On LvUp: high friendship", "On LvUp: high friendship & is day", "On LvUp: high friendship & is night",
    "On LvUp: Lv ≥ LvReq", "On Trade", "On Trade: holds item", "Karrablast/Shelmet Trade",
    "On UseItem", "On LvUp: Lv ≥ LvReq & Atk > Def", "On LvUp: Lv ≥ LvReq & Def > Atk", "On LvUp: Lv ≥ LvReq & Atk = Def",
    "On LvUp: Lv ≥ LvReq & rng(0-9) ≤ 4", "On LvUp: Lv ≥ LvReq & rng(0-9) > 4", "On LvUp: Lv ≥ LvReq → Get Shedinja", "SPECIAL_NUKENIN",
    "On LvUp: high beauty", "On UseItem: is male", "On UseItem: is female", "On LvUp: Lv ≥ LvReq & holds item & is day",
    "On LvUp: Lv ≥ LvReq & holds item & is night", "On LvUp: has move", "On LvUp: Pokémon in party", "On LvUp: Lv ≥ LvReq & is male",
    "On LvUp: Lv ≥ LvReq & is female", "On LvUp: is by magnetic field", "On LvUp: is by moss rock", "On LvUp: is by ice rock",
    "On LvUp: Lv ≥ LvReq & device upside down", "On LvUp: high friendship & has move of type", "On LvUp: Lv ≥ LvReq & Dark Pokémon in party", "On LvUp: Lv ≥ LvReq & is raining",
    "On LvUp: Lv ≥ LvReq & is day", "On LvUp: Lv ≥ LvReq & is night", "On LvUp: Lv ≥ LvReq & is female → set form to 1", "FRIENDLY",
    "On LvUp: Lv ≥ LvReq & is game version", "On LvUp: Lv ≥ LvReq & is game version & is day", "On LvUp: Lv ≥ LvReq & is game version & is night", "On LvUp: is by summit",
    "On LvUp: Lv ≥ LvReq & is dusk", "On LvUp: Lv ≥ LvReq & is outside region", "On UseItem: is outside region", "Galarian Farfetch'd Evolution",
    "Galarian Yamask Evolution", "Milcery Evolution", "On LvUp: Lv ≥ LvReq & has amped nature", "On LvUp: Lv ≥ LvReq & has low-key nature"
]

const EVOLUTION_METHOD_REQUIRES_LEVEL = [
    false, false, false, false, true, false, false, false, false, true, true, true, true, true, true, true,
    false, false, false, true, true, false, false, true, true, false, false, false, true, false, true, true,
    true, true, true, false, true, true, true, false, true, true, false, false, false, false, true, true
]

const None = 0, Item = 1, Move = 2, Pokemon = 3, Typing = 4, GameVersion = 5;
const EVOLUTION_METHOD_PARAM_TYPE = [
    None, None, None, None,
    None, None, Item, None,
    Item, None, None, None,
    None, None, None, None,
    None, Item, Item, Item,
    Item, Move, Pokemon, None,
    None, None, None, None,
    None, Typing, None, None,
    None, None, None, None,
    GameVersion, GameVersion, GameVersion, None,
    None, None, Item, None,
    None, None, None, None,
]
/**
 Untouched properties:
 color
 gra_no
 get_rate
 exp_value
 item1
 item2
 item3
 sex
 egg_birth
 initial_friendship
 egg_group1
 egg_group2
 grow
 give_exp
 */

function parseTmLearnsetSection(dec) {
    return (dec >>> 0).toString(2).split('').reverse().join('').padStart(32, 0);
}

function getName(monsno = 0) {
    return basePokemonNames.labelDataArray[monsno]?.wordDataArray[0]?.str || 'Egg';
}

function getFormName(formId) {
    return formPokemonNames.labelDataArray[formId]?.wordDataArray[0]?.str || 'Egg';
}

function getImage(monsno = 0) {
    return `/img/pm${monsno.toString().padStart(4, 0) ?? '0000'
        }_00_00_00_L.webp`
};

function getHeight(monsno = 0) {
    const heightString = pokemonHeight.labelDataArray[monsno]?.wordDataArray[0]?.str || '0';
    const [feetString, inchesString] = heightString.split("'");
    const inches = parseFloat(inchesString.substring(0, inchesString.length - 1));
    const feet = parseInt(feetString);

    const feetInCentimeters = feet * 30.48;
    const inchesInCentimeters = inches * 2.54;
    return ((feetInCentimeters + inchesInCentimeters) / 100).toFixed(2);
}

function getWeight(monsno = 0) {
    const weightString = pokemonWeight.labelDataArray[monsno]?.wordDataArray[0]?.str || '0';

    const [poundsString] = weightString.split(" ");
    const pounds = parseFloat(poundsString.trim());

    const poundsInKilogram = pounds * 0.453592;
    return poundsInKilogram.toFixed(2);
}

function getType(typeId) {
    return typeName.labelDataArray[typeId]?.wordDataArray[0]?.str || 'None';
}

function getNature(id = 0) {
    return natureNames.labelDataArray[id]?.wordDataArray[0]?.str || 'None';
}

function formatBaseStats(p) {
    return `HP: ${p.basic_hp} / ATK: ${p.basic_atk} / DEF: ${p.basic_def} / SPA: ${p.basic_spatk} / SPD: ${p.basic_spdef} / SPE: ${p.basic_agi}`;
}

function getAbility(id) {
    return abilityNames.labelDataArray[id]?.wordDataArray[0]?.str || 'None';
}
function getAbilityInfo(id) {
    return abilityInfo.labelDataArray[id]?.wordDataArray[0]?.str || 'None';
}

function getTechMachineLearnset(m1, m2, m3, m4) {
    const learnset = [
        parseTmLearnsetSection(m1),
        parseTmLearnsetSection(m2),
        parseTmLearnsetSection(m3),
        parseTmLearnsetSection(m4),
    ].join('').split('').flatMap(e => parseInt(e));

    const canLearn = [];
    for (let i = 0; i < learnset.length; i++) {
        if (learnset[i] === 0) continue;

        const tm = ItemTable.WazaMachine[i];
        const tmName = itemNames.labelDataArray[tm.itemNo].wordDataArray[0].str;
        const moveName = moveNames.labelDataArray[tm.wazaNo].wordDataArray[0].str;
        canLearn.push(`${tmName} - ${moveName}`);
    }

    return canLearn;
}

function getGrassKnotPower(weightkg) {
    if (weightkg >= 200) return 120;
    if (weightkg >= 100) return 100;
    if (weightkg >= 50) return 80;
    if (weightkg >= 25) return 60;
    if (weightkg >= 10) return 40;
    return 20;
}

function getPokemonInfo(monsno = 0) {
    const p = PersonalTable.Personal[monsno];
    return {
        monsno: monsno,
        name: getName(monsno),
        ability1: getAbility(p.tokusei1),
        ability2: getAbility(p.tokusei2),
        abilityH: getAbility(p.tokusei3),
        tmLearnset: getTechMachineLearnset(p.machine1, p.machine2, p.machine3, p.machine4),
        prettyBaseStats: formatBaseStats(p),
        baseStats: {
            hp: p.basic_hp, atk: p.basic_atk, def: p.basic_def, spa: p.basic_spatk, spd: p.basic_spdef, spe: p.basic_agi
        },
        baseStatsTotal: p.basic_hp + p.basic_atk + p.basic_def + p.basic_spatk + p.basic_spdef + p.basic_agi,
        weight: getWeight(monsno),
        height: getHeight(monsno),
        grassKnotPower: getGrassKnotPower(getWeight(monsno)),
        type1: getType(p.type1),
        type2: getType(p.type2),
        imageSrc: getImage(monsno)
    }
}

function getPokemonNames(maxMonsno) {
    const pokemonNames = [];
    for (let nameObject of basePokemonNames.labelDataArray) {
        if (typeof maxMonsno === 'number' && nameObject.arrayIndex > maxMonsno) return pokemonNames;
        pokemonNames.push(nameObject.wordDataArray[0].str)
    }

    return pokemonNames;
}

function getPokemonIdFromName(name = 'Egg') {
    return POKEMON_MAP[name];
}

function createEvoPath(currentMonId, targetMonId, method) {
    return;
}

function getEvolutionData(monId = 0) {
    const evos = EvolveTable.Evolve.find(e => e.id === monId).ar;
    const evoPaths = [];

    for (let i = 0; i < evos.length; i += 5) {
        const [method, parameter, target, targetFormId, level] = evos.slice(i, i + 5);
        console.log(method, parameter, target, targetFormId, level)
        evoPaths.push(`${getName(monId)} evolves ${EVOLUTION_METHODS[method]} ${!!parameter ? `using ${EVOLUTION_METHOD_PARAM_TYPE[method]}` : ''} to ${getName(target)} ${EVOLUTION_METHOD_REQUIRES_LEVEL[method] ? `at level ${level}` : ''}`.trim());
    }
    console.log(evoPaths, monId, evos);
    return evoPaths;
}

function getMoveProperties(moveId = 0) {
    const { type, damageType, power, hitPer, basePP } = MovesTable.Waza[moveId];
    const maxPP = (basePP ?? 0) * (8 / 5);
    return {
        name: moveNames.labelDataArray[moveId].wordDataArray[0]?.str ?? 'None',
        desc: getMoveDescription(moveId),
        type,
        damageType, //0 = Status, 1 = Physical, 2 = Special
        maxPP,
        power,
        accuracy: hitPer
    }
}

function getPokemonLearnset(monsno = 0) {
    return LearnsetTable.WazaOboe[monsno].ar;
}

function getMoveDescription(moveId = 0) {
    const wordData = moveInfo.labelDataArray[moveId].wordDataArray;
    let description = wordData.reduce(
        (moveDescription, currentString) => {
            return moveDescription + currentString.str + ' ';
        }, '')
    return description;
}

module.exports = {
    getPokemonInfo,
    getAbilityInfo,
    getEvolutionData,
    getPokemonNames,
    getPokemonIdFromName,
    getMoveProperties,
    getPokemonLearnset,
    getType
}